<?php
//000000086400a:9:{s:2:"id";s:2:"11";s:5:"title";s:59:"Uzi：单挑王让更多人认识我 和Rekkles配合很好";s:7:"content";s:3822:"<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""> <span style="font-size:14px;">&nbsp; 2016英雄联盟全明星赛solo赛在今天北京时间今天半夜正式结束，最终Uzi取得了2016全明星solo赛的冠军！赛后小狗接受了媒体的采访看一下说了些什么吧。</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：在舞台上接受采访时你说你想尽了各种方法赢得SOLO赛冠军，可以说一下你都想了什么方法吗？</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 我一直都在想打他们的对策，有一天我做梦的时候都在想。</span><span style="font-size:14px;line-height:1.5;">{img1}</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><br />
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：小狗你的第一个冠军拿的就是SOLO赛的冠军，这次的心情有什么不一样？</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 我第一次拿solo冠军的时候游戏还没有这么多人知道，也没有很多人关注那个比赛，这个比赛让更多的人认识我了吧。</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：为什么刚才赢了比赛之后一脸懵逼？</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 因为很开心，我玩的英雄就那么几个很害怕被对面各种套路针对，能赢很开心。</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：辛德拉是在怎样的情况下选出来的？对自己的辛德拉很自信吗？</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 我实在是被法王逼得没办法了，第一局赢得很难第二局又输了，我想的是放出辛德拉他选我也选，之后就拼拼补刀的运气吧，那个时候实在想不出哪个英雄可以和他打。</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><br />
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：双人共玩模式的时候和Rekkles配合的时候有没有什么障碍，你们的老鼠发挥的也很强，你们是怎么跨越语言的障碍的？</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> 我和他其实没有特别多的沟通，但是比赛之前我们去自定义试过发现老鼠两个人配合度不用特别高也可以玩的很好，他也问我说想玩老鼠还是VN，到最后还是选择了老鼠配合方面也没有很大的障碍。</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; Q：和法王solo的时候在他的主场赢得比赛的胜利心情是什么样的？</span>
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> 心情肯定是非常开心，他玩的真的特别的强，把我打的一下子想不出怎么玩了。</span>
	</p>
	<p>
		<br />
	</p>
	<p>
		<br />
	</p>";s:5:"hints";s:3:"601";s:6:"author";s:15:"多玩游戏网";s:4:"time";s:19:"2016-12-16 16:04:41";s:6:"source";s:15:"新网游新闻";s:8:"overview";s:211:"今日凌晨，在巴塞罗那举行的LOL2016全明星赛中，LPL选手Uzi获得了solo赛冠军。赛后Uzi接受采访。小狗称solo冠军会让更多人认识自己。双人模式和Rekkles配合很好。";s:3:"nid";s:1:"1";}
?>