<?php
//000000086400a:2:{i:0;a:5:{s:5:"imgId";s:2:"26";s:7:"imgname";s:13:"140886792.jpg";s:7:"special";s:1:"1";s:6:"newsid";s:2:"11";s:6:"shunxu";s:1:"0";}i:1;a:5:{s:5:"imgId";s:2:"27";s:7:"imgname";s:13:"140886791.jpg";s:7:"special";s:1:"0";s:6:"newsid";s:2:"11";s:6:"shunxu";s:1:"1";}}
?>