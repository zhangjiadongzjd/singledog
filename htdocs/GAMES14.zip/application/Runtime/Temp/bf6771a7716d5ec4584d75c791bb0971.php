<?php
//000000086400a:9:{s:2:"id";s:2:"12";s:5:"title";s:69:"战力评级全新活动火热开启《问道》百万奖金大放送";s:7:"content";s:3507:"<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""> <span style="font-size:14px;">&nbsp; 《</span><a class="a-tips-Article-QQ" href="http://datalib.games.qq.com/net_game/26/index.shtml" target="_blank"><span style="font-size:14px;">问道</span></a><span style="font-size:14px;">(</span><span class="infoMblog"><a class="a-tips-Article-QQ" href="http://t.qq.com/wendao2006#pref=qqcom.keyword" target="_blank"><span style="font-size:14px;">微博</span></a></span><span style="font-size:14px;">)：元神合一》新资料片火爆公测中，全新战力系统震撼来袭，海量新玩法掀起修仙新高潮，打破中州战斗格局！更有薛之谦化身</span><a class="a-tips-Article-QQ" href="http://datalib.games.qq.com/tv_game/8/index.shtml" target="_blank"><span style="font-size:14px;">战神</span></a><span style="font-size:14px;">，诚邀百万道友前来助阵，战力爆发豪送百万福利！</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 《问道》官网：</span><a href="http://wd.gyyx.cn/"><span style="font-size:14px;">http://wd.gyyx.cn</span></a> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 《问道》战力大爆发：</span><span style="font-size:14px;"><a href="http://actionv2.gyyx.cn/2016/xzq">http://actionv2.gyyx.cn/2016/xzq</a></span><span style="font-size:14px;line-height:1.5;">&nbsp; {img1}</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><br />
</p>
<div id="contTxt" style="font-family:" font-size:16px;background-color:#ffffff;"="">
<p>
	<span style="font-size:14px;">&nbsp; 《问道：元神合一》新资料片“战力系统”震撼登陆，作为本次新资料片的一大特色，战力系统的评级和评分功能吸引无数道友前去体验，一时热度非凡。在战力系统中，“战力值”和“评级”会对角色的属性进行实时统计，属性发生变化时会自动更新当前战力评分和评级。玩家可在人物属性界面增加战力和评级显示，也可通过人物属性界面打开战力界面。</span>
</p>
<p>
	<span style="font-size:14px;">&nbsp; “战力系统”提供战力提升的快捷方式，玩家可通过提升装备、法宝、悟道、引灵幡等方法快速提升战力评分和评级，从而打造最强战力！同时，界面最下方也会增加战力排行榜，玩家可查看自身排行，明确中州战力局势！</span>
</p>
	</div>
<div id="PGViframe" style="font-family:" font-size:16px;background-color:#ffffff;"="">
</div>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> 《问道》年度大型资料片“元神合一”震撼来袭，中州世界焕然一新，战力玩法再引修道新高潮！更有全新福利活动同步上线，百万好礼豪情相送！同时，《问道》</span><a class="a-tips-Article-QQ" href="http://games.qq.com/mobile/" target="_blank"><span style="font-size:14px;">手游</span></a><span style="font-size:14px;">年度版12月1日公测，带来全新坐骑、角色交易。不要犹豫，快来中州一战！</span>
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"><br />
</span>
</p>
<p>
	<br />
</p>";s:5:"hints";s:3:"567";s:6:"author";s:12:"腾讯游戏";s:4:"time";s:19:"2016-12-16 16:04:44";s:6:"source";s:24:"大陆网游厂商新闻";s:8:"overview";s:0:"";s:3:"nid";s:1:"1";}
?>