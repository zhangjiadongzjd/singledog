<?php
//000000086400a:3:{i:0;a:3:{s:2:"id";s:1:"1";s:13:"gamestypename";s:12:"网络游戏";s:7:"newsnum";s:1:"0";}i:1;a:3:{s:2:"id";s:1:"2";s:13:"gamestypename";s:12:"单机游戏";s:7:"newsnum";s:1:"0";}i:2;a:3:{s:2:"id";s:1:"3";s:13:"gamestypename";s:12:"手机游戏";s:7:"newsnum";s:1:"0";}}
?>