<?php
//000000086400a:1:{i:0;a:5:{s:5:"imgId";s:2:"28";s:7:"imgname";s:31:"24135850190fbd5db3.04784745.jpg";s:7:"special";s:1:"1";s:6:"newsid";s:2:"12";s:6:"shunxu";s:1:"0";}}
?>