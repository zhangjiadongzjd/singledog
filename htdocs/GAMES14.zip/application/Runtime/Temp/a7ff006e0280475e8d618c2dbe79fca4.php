<?php
//000000086400a:9:{s:2:"id";s:1:"9";s:5:"title";s:67:"经典职业将迎第二春《征途2》年终福利版激情开启";s:7:"content";s:7001:"<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""> <span style="font-size:14px;">&nbsp; 12月16日，《征途2（</span><span class="infoMblog"><a target="_blank" href="http://t.qq.com/gazhengtu2#pref=qqcom.keyword" class="a-tips-Article-QQ"><span style="font-size:14px;">微博</span></a></span><span style="font-size:14px;">)》年终福利版激情开战，除了海量年终福利席卷而来，经典职业技能和数值大调整，也是本次年终福利版的重头戏。</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> 此次，经典职业技能和数值调整包括战士和琴师两大职业，调整后，战士与琴师除继续保持原有的特点外，原本劣势完美逆转，变劣为优。职业调整势必将迎来职业大洗牌，两大经典职业将迎来第二春。</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 战士技能大调整，狂战守护战逆天而起</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 曾经被誉为《征途2》单挑之王的战士，在新职业不断入驻的冲击下，逐渐光芒暗淡。本次，《征途2》年终福利版将对战士职业进行重大调整，其中包括数值调整，令昔日单挑之王重现</span><a class="a-tips-Article-QQ" href="http://datalib.games.qq.com/net_game/275/index.shtml" target="_blank"><span style="font-size:14px;">辉煌</span></a><span style="font-size:14px;">，重返最高王者舞台。</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 此次，《征途2》战士技能与数值调整，主要针对战士技能劣势优化，将战士移动速度加快，抵抗负面状态效果加强，攻击能力提升等，使战士原本处于劣势的状态摇身变成优势，实力完成180度转，尤其是速度上的飞升，使得战士犹如猛虎下山，势不可挡。</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> 战士技能调整后，战士的战斗策略也将发生改变，原本防御力就很强的战士防御力更强，尤其是守护战，可以与高出自己两个层次的其他职业对战，通过输出来破除对方防御，软磨硬泡将对手磨死。</span><span style="font-size:14px;line-height:1.5;">&nbsp;{img1}</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 琴师魔音加强，重新找回战场存在感</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 昔日，《征途2》琴师是战场上必不可少的存在，仙音被誉为大奶，而魔音是强大的辅助存在。随着游戏职业攻击力的与日增强，琴师致命的低防御力，使其在战场上，尤其是在团战中，优势荡然无存，也使得昔日经典的琴师职业逐渐没落。</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 虽然琴师没落，但战场上奶妈的重要性使得仙音仍然有一定的地位，但魔音的地位则更为尴尬，因此，此次《征途2》经典职业改版中，魔音成为技能升级和数值调整的重头戏。</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 魔音此次重点调整一方面是调整了塔的攻击范围，另一方面万劫诅咒与迟缓之塔可叠加使用，让魔音在群战中的实力瞬间“变态”起来，魔音在战场上的作用大幅提升，令其重现昔日战场之辉煌，找回战场存在感。</span><span style="font-size:14px;">{img2}</span><span style="line-height:1.5;font-size:14px;">&nbsp;</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 推新而不忘经典，关注玩家情感</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 新职业推出，可使玩家不断保持着不同的新体验，对整体玩家体验感来说是加分的，但对于忠实粉丝来说，昔日的经典职业“没落”则会感伤不已。</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp;&nbsp;前不久，《征途2》推出神圣弓箭手和</span><a class="a-tips-Article-QQ" href="http://datalib.games.qq.com/tv_game/851/index.shtml" target="_blank"><span style="font-size:14px;">黑暗</span></a><span style="font-size:14px;">法师两大新职业后，掀起了一波转新职业的风潮，在大家对新职业体验透彻之后，开始怀念最初的经典职业。</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 其实，关于经典职业的革新，《征途2》项目组早在一年前就着手规划，通过玩家及问卷调查等多重手段分析后，开启经典职业优化之旅。</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 作为经典国战</span><a class="a-tips-Article-QQ" href="http://games.qq.com/ntgame/netgame.shtml" target="_blank"><span style="font-size:14px;">网游</span></a><span style="font-size:14px;">，《征途2》经典职业已悄然陪伴大家走过六个年头，虽然每次推出的新职业都能引发玩家轰动，但经典职业不应该被埋没，而应该不断与时俱进，与游戏一起成长，一起不断强大，而如今，《征途2》也是这么做的。</span><span style="font-size:14px;">{img3}</span><span style="line-height:1.5;font-size:14px;">&nbsp;</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 《征途2》2016年终盛典即将开启，经典职业将迎第二春，一场经典职业与新晋职业之间的巅峰对决，即将开启，谁才是不败王者？让我们拭目以待吧！</span> 
</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"> &nbsp; 详情请关注《征途2》官网：http://zt2.ztgame.com</span> 
	</p>
<p style="font-family:" font-size:16px;text-indent:2em;background-color:#ffffff;"=""><span style="font-size:14px;"><br />
</span>
</p>
<p>
	<span style="font-size:14px;"></span> 
</p>";s:5:"hints";s:3:"801";s:6:"author";s:12:"腾讯游戏";s:4:"time";s:19:"2016-12-16 16:04:31";s:6:"source";s:24:"大陆网游厂商新闻";s:8:"overview";s:176:"12月16日，《征途2》年终福利版激情开战，除了海量年终福利席卷而来，经典职业技能和数值大调整，也是本次年终福利版的重头戏。";s:3:"nid";s:1:"1";}
?>